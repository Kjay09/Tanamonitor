package com.example.tanamonitor;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

public class Preferences {
    static final String KEY_APPLIED_THRESHOLD = "threshold";
}
